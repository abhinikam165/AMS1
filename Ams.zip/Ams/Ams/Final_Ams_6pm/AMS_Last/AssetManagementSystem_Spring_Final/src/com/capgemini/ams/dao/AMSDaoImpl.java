package com.capgemini.ams.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

@Repository
public class AMSDaoImpl implements IAMSDao {
	

	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = Logger.getLogger(AdminDAOImpl.class);
	
	/* 
	 * This method will show a list of available asset to both admin and manager.
	 */
	@Override
	public ArrayList<Asset> showAllAssets() throws AssetException 
	{
		ArrayList<Asset> assetList = new ArrayList<Asset>();
		
		String sql = "SELECT asset FROM Asset asset";
		TypedQuery<Asset> query = entityManager.createQuery(sql, Asset.class);
		assetList = (ArrayList<Asset>) query.getResultList();
		
		if(assetList.size() == 0)
		{
			logger.error("No Record Found in Asset Table");
			throw new AssetException("No records found in database");
		}
		return assetList;
	}

	/* 
	 * This method will show list of requests raised by manager , Manager can only view request 
	 * whereas admin can view as well as approve requests.
	 */
	@Override
	public ArrayList<AssetRequest> showAllRequests() throws AssetException
	{
		ArrayList<AssetRequest> requestList = new ArrayList<AssetRequest>();

		String sql = "SELECT request FROM AssetRequest request";
		TypedQuery<AssetRequest> query = entityManager.createQuery(sql, AssetRequest.class);
		
		requestList = (ArrayList<AssetRequest>) query.getResultList();
		
		if(requestList.size() == 0)
		{
			logger.error("No Record Found in Asset Table");
			throw new AssetException("No requests found in the database");
		}
		return requestList;
	}

	/* 
	 * This method will extract asset details by taking input as assetid, Both manager and admin 
	 * can access this functionality.
	 */
	@Override
	public Asset getAssetDetailsById(long assetid) throws AssetException 
	{
		Asset asset=null;
		asset = entityManager.find(Asset.class, assetid);
		if(asset == null)
		{
			throw new AssetException("Asset with asset id "+assetid+" not found..");
		}
		return asset;
	}

}
