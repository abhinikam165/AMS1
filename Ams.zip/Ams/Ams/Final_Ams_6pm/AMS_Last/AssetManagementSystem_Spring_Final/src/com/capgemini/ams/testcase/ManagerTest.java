package com.capgemini.ams.testcase;

import org.junit.Before;

import com.capgemini.ams.dao.ManagerDAOImpl;
import com.capgemini.ams.service.ManagerServiceImpl;

public class ManagerTest {

	ManagerServiceImpl managerService;
	ManagerDAOImpl managerDao;

	@Before
	public void init() {
		managerService = new ManagerServiceImpl();
		managerDao = new ManagerDAOImpl();
		managerService.setDao(managerDao);
	}
}
