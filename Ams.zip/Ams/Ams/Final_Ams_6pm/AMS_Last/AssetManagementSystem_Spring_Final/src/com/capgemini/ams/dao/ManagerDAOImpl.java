 package com.capgemini.ams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

@Repository
public class ManagerDAOImpl implements IManagerDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = Logger.getLogger(AdminDAOImpl.class);
	
	/* 
	 * This methods raise a request for an employee by taking input as Asset id,Asset name,Asset description,
	 * Asset quantity and Employee number . This functionality can only perform by manager.
	 */
	@Override
	public long raiseRequest(AssetRequest assetRequest) throws AssetException {

		System.out.println("in man dao");
		entityManager.persist(assetRequest);
		entityManager.flush();
		
		long requestId = assetRequest.getRequestid();
		
		return requestId;
	}
	
}
