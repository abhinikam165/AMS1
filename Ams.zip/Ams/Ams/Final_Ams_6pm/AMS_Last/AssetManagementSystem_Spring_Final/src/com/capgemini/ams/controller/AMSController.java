package com.capgemini.ams.controller;



import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.IAMSService;

@Controller
public class AMSController extends MultiActionController{
	
	@Autowired
	IAMSService amsService;
	
	String url = null;
	String errorMessage = null;
	String successMessage = null;
	
	
	/**On clicking on show request,it will redirect to requests page and successfully 
	 * display all request by manager but if there is  no  request it will display an error page 
	 * @param userType It fetches userType parameter   and  stores it in userType. 
	 * @param model It will store object of userType.
	 * @return
	 */
	@RequestMapping("/showRequestList")
	public String showAllRequests(@RequestParam("userType")String userType, Model model)
	{
		ArrayList<AssetRequest> requestList = null;
		try 
		{
			requestList = amsService.showAllRequests();
			model.addAttribute("userType",userType);
			model.addAttribute("requestList",requestList);
			url = "Requests";
			
		} 
		catch (AssetException e) 
		{
			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}	
		return url;
	}
	
	/**On clicking on Show asset list,it will redirect to asset list page and successfully 
	 * display all asset  but if there is  no  asset it will display an error page 
	 * @param userType It fetches userType parameter   and  stores it in userType.
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/showAssetList")
	public String raiseRequest(@RequestParam("userType") String userType, Model model)
	{		
		ArrayList<Asset> assetList=new ArrayList<Asset>();
		try 
		{
			assetList=amsService.showAllAssets();
			model.addAttribute("assetList", assetList);
			System.out.println("User Type : "+ userType);
			model.addAttribute("userType",userType);
			url = "AssetList";
			
		} catch (AssetException e) {
			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}
		return url;
	}
}