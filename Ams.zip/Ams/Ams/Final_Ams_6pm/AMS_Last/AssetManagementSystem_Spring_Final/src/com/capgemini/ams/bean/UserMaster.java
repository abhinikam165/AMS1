package com.capgemini.ams.bean;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;


/**
 * The persistent class for the USER_MASTER database table.
 * 
 */
@Entity
@Component
@Table(name="USER_MASTER")
@NamedQuery(name="UserMaster.findAll", query="SELECT u FROM UserMaster u")
/*@NamedQuery(name="UserMaster.validateUser", query="SELECT user FROM UserMaster user WHERE user.username=:uname AND user.userpassword=:upass")
*/
public class UserMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USER_MASTER_USERID_GENERATOR", sequenceName="SEQ_USERID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_MASTER_USERID_GENERATOR")
	private String userid;

	@NotEmpty
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="First letter should be capital.")
	private String username;

	@NotEmpty
	@Pattern(regexp="[A-Za-z0-9]{8}", message="Minimum length of password is 8 should contain Capitals, numbers and digits.")
	private String userpassword;

	private String usertype;

	//bi-directional many-to-one association to Employee
	@ManyToOne
	@JoinColumn(name="EMPNUM")
	private Employee employee;

	public UserMaster() {
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return this.userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public String getUsertype() {
		return this.usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}