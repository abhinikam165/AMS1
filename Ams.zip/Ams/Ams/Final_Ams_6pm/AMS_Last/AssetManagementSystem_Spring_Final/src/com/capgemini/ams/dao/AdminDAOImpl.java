package com.capgemini.ams.dao;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetAllocation;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

@Repository
public class AdminDAOImpl implements IAdminDAO {


	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = Logger.getLogger(AdminDAOImpl.class);

	/* 
	 * This method is use to add asset by taking input as asset name,asset description,asset quantity.
	 * This functionality can only be perform by admin.
	 */
	@Override
	public boolean addAsset(Asset asset) throws AssetException {
		
		boolean flag = false;
		
		entityManager.persist(asset);
		entityManager.flush();
		flag = true;
		
		logger.info("Asset "+asset.getAssetName()+" added successfully");
		
		return flag;
	}

	

	/* 
	 * This method is use to allocate asset to respective employee.Moreover status 
	 * changes to allocated and quantity is also updated after allocation of asset.
	 * Asset allocation can only be done by admin.
	 */
	@Override
	public boolean allocateAsset(long requestId,LocalDate releaseDate) throws AssetException {
		boolean flag = false;
		
		AssetRequest request = null;
		
		request = entityManager.find(AssetRequest.class, requestId);
		
		AssetAllocation assetAllocation = new AssetAllocation();
		
		assetAllocation.setAllocationDate(Date.valueOf(LocalDate.now()));
		assetAllocation.setReleaseDate(Date.valueOf(releaseDate));
		assetAllocation.setAsset(request.getAsset());
		assetAllocation.setEmployee(request.getEmployee1());
		
		Asset reqAsset =  request.getAsset();
		Integer reqQuantity = request.getQuantity().intValue();
		Integer availableQuant = reqAsset.getQuantity().intValue();
		
		Integer updateQuant = availableQuant - reqQuantity;
		
		reqAsset.setQuantity(updateQuant);
		logger.info("Asset quantity for asset id "+reqAsset.getAssetId()+" updated to "+reqAsset.getQuantity());
		
		request.setStatus("Allocated");
		
		
		entityManager.merge(request);
		
		entityManager.merge(reqAsset);
		logger.info("Status of request id "+requestId+" changed to 'Allocated'");
		
		entityManager.persist(assetAllocation);
		logger.info("Asset successfully allocated to request id "+requestId);
		
		return flag;
	}


	/* 
	 * This method is use to generate report in csv/excel format.
	 */
	@Override
	public boolean generateReport() throws AssetException {
		boolean flag = false;
	
		try {
			
			FileWriter fos = new FileWriter("P:/Users/pdurge/Desktop/Asset/AMS_Edit/AssetManagementSystem_Spring_Sudhir/Asset_Allocation.csv");
			ArrayList<AssetAllocation> assetAllocationList = null;
			
			
			String sql = "SELECT assetAllocation FROM AssetAllocation assetAllocation";
			TypedQuery<AssetAllocation> query = entityManager.createQuery(sql, AssetAllocation.class);
			
			assetAllocationList = (ArrayList<AssetAllocation>) query.getResultList();
			System.out.println(assetAllocationList);
			
			fos.write("AllocationId,AssetId,EmpNum,AllocationDate,ReleaseDate \n");
			
			for(AssetAllocation assetAllcoation : assetAllocationList)
			{
				fos.write(String.valueOf(assetAllcoation.getAllocationid()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getAsset().getAssetId()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getEmployee().getEmpnum()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getAllocationDate()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getReleaseDate()));
				fos.write("\n");
				
				System.out.println("success");
				fos.flush();
				
			}
			fos.close();
			
			logger.info("Asset Allocation report generated.. ");
			
			flag = true;
			
		} 
		catch (IOException e) 
		{
			throw new AssetException("File operation Exception ");
		}
		return flag;
	}

	/* 
	 * This method is use to modify an existing asset.
	 */
	@Override
	public boolean modifyAsset(Asset asset) throws AssetException 
	{
		boolean flag = false;
		entityManager.merge(asset);
		entityManager.flush();
		flag = true;
	
		return flag;
	}

}
