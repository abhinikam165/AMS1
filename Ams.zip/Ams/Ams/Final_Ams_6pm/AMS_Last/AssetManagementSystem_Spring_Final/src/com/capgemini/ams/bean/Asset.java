package com.capgemini.ams.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the ASSET database table.
 * 
 */
@Entity
@Component
@NamedQuery(name="Asset.findAll", query="SELECT a FROM Asset a")
public class Asset implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ASSET_ASSETID_GENERATOR", sequenceName="SEQ_ASSETID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ASSET_ASSETID_GENERATOR")
	private long assetId;

/*	@NotEmpty(message="\"Asset Description\" may not be empty and first letter should be capital.")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="")*/
	private String assetDes;
	
/*	@NotEmpty(message="\"Asset Name\" may not be empty and first letter should be capital.")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="")*/
	private String assetName;
	
/*
	@NotNull(message="\"Quantity\" may not be empty and should be in the range of 01-100")
	@Range(min=1,max=100, message="")*/
	private Integer quantity;

	//bi-directional many-to-one association to Assetallocation
	@OneToMany(mappedBy="asset")
	private List<AssetAllocation> assetAllocations;

	//bi-directional many-to-one association to Assetrequest
	@OneToMany(mappedBy="asset")
	private List<AssetRequest> assetRequests;

	public Asset() {
	}

	public long getAssetId() {
		return this.assetId;
	}

	public void setAssetId(long assetId) {
		this.assetId = assetId;
	}

	public String getAssetDes() {
		return this.assetDes;
	}

	public void setAssetDes(String assetDes) {
		this.assetDes = assetDes;
	}



	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(Integer updateQuant) {
		this.quantity = updateQuant;
	}

	public List<AssetAllocation> getAssetAllocations() {
		return this.assetAllocations;
	}

	public void setAssetAllocations(List<AssetAllocation> assetAllocations) {
		this.assetAllocations = assetAllocations;
	}

	public AssetAllocation addAssetAllocation(AssetAllocation assetAllocation) {
		getAssetAllocations().add(assetAllocation);
		assetAllocation.setAsset(this);

		return assetAllocation;
	}

	public AssetAllocation removeAssetAllocation(AssetAllocation assetAllocation) {
		getAssetAllocations().remove(assetAllocation);
		assetAllocation.setAsset(null);

		return assetAllocation;
	}

	public List<AssetRequest> getAssetRequests() {
		return this.assetRequests;
	}

	public void setAssetrequests(List<AssetRequest> assetRequests) {
		this.assetRequests = assetRequests;
	}

	public AssetRequest addAssetRequest(AssetRequest assetRequest) {
		getAssetRequests().add(assetRequest);
		assetRequest.setAsset(this);

		return assetRequest;
	}

	public AssetRequest removeAssetRequest(AssetRequest assetRequest) {
		getAssetRequests().remove(assetRequest);
		assetRequest.setAsset(null);

		return assetRequest;
	}

}