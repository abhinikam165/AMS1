package com.capgemini.ams.dao;

import java.util.ArrayList;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public interface IAMSDao {

	ArrayList<Asset> showAllAssets() throws AssetException;

	ArrayList<AssetRequest> showAllRequests()throws AssetException;

	Asset getAssetDetailsById(long assetId) throws AssetException;
	
}
